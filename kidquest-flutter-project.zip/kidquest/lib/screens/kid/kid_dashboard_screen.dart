import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../models/task_model.dart';
import '../../utils/theme.dart';
import '../../widgets/task_card.dart';
import '../../widgets/points_badge.dart';
import '../auth/role_selection_screen.dart';
import 'kid_rewards_screen.dart';

class KidDashboardScreen extends StatefulWidget {
  const KidDashboardScreen({super.key});

  @override
  State<KidDashboardScreen> createState() => _KidDashboardScreenState();
}

class _KidDashboardScreenState extends State<KidDashboardScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final kid = auth.currentKid!;

    final pages = [
      _KidTasksTab(kidId: kid.id),
      const KidRewardsScreen(),
    ];

    return Scaffold(
      backgroundColor: AppColors.kidBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(kid.avatar, style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 8),
            Text('Hi, ${kid.username}!'),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Center(child: PointsBadge(points: kid.totalPoints)),
          ),
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: () async {
              await auth.logout();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.checklist_rtl_rounded), label: 'My Quests'),
          NavigationDestination(icon: Icon(Icons.card_giftcard_rounded), label: 'Rewards'),
        ],
      ),
    );
  }
}

class _KidTasksTab extends StatelessWidget {
  final String kidId;
  const _KidTasksTab({required this.kidId});

  @override
  Widget build(BuildContext context) {
    final taskProvider = context.watch<TaskProvider>();
    final tasks = taskProvider.tasksForKid(kidId);
    final approvedCount = tasks.where((t) => t.status == TaskStatus.approved).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: AppColors.kidGradient),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Row(
            children: [
              const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 40),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('You completed $approvedCount quest(s)!',
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 4),
                    const Text('Keep going to earn more rewards 🌟',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('My Quests', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        if (tasks.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No quests yet. Ask your parent to add one!',
                  style: TextStyle(color: Colors.grey[500])),
            ),
          )
        else
          ...tasks.map((t) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: TaskCard(
                  task: t,
                  onTap: () => showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      title: const Text('🔒 Locked'),
                      content: const Text(
                          'Ask your parent for the code to change this quest.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('OK'),
                        ),
                      ],
                    ),
                  ),
                  trailing: t.status == TaskStatus.pending || t.status == TaskStatus.rejected
                      ? ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.success,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          ),
                          onPressed: () async {
                            await context.read<TaskProvider>().markDoneByKid(t);
                          },
                          child: const Text('Done!'),
                        )
                      : null,
                ),
              )),
      ],
    );
  }
}
