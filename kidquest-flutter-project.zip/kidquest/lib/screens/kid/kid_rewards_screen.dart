import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/reward_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/pin_dialog.dart';

class KidRewardsScreen extends StatelessWidget {
  const KidRewardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final rewardProvider = context.watch<RewardProvider>();
    final kid = auth.currentKid!;
    final rewards = rewardProvider.rewardsForParent(kid.parentId);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Reward Store', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text('You have ${kid.totalPoints} points to spend',
            style: TextStyle(color: Colors.grey[600])),
        const SizedBox(height: 16),
        if (rewards.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No rewards yet. Ask your parent to add some!',
                  style: TextStyle(color: Colors.grey[500])),
            ),
          )
        else
          ...rewards.map((reward) {
            final canAfford = kid.totalPoints >= reward.pointsRequired;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: AppColors.secondary.withOpacity(0.15),
                        child: Text(reward.icon, style: const TextStyle(fontSize: 22)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(reward.title,
                                style: const TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text('${reward.pointsRequired} points',
                                style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              canAfford ? AppColors.primary : Colors.grey[300],
                          foregroundColor: canAfford ? Colors.white : Colors.grey[600],
                        ),
                        onPressed: () async {
                          // Redeeming requires the parent's PIN, so the kid
                          // can't spend points without adult confirmation.
                          final ok = await showParentPinDialog(
                            context,
                            reason:
                                'Ask a parent to enter their PIN to redeem "${reward.title}".',
                          );
                          if (!ok) return;
                          final error = await context
                              .read<RewardProvider>()
                              .redeem(reward: reward, kid: kid);
                          if (!context.mounted) return;
                          if (error != null) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text(error)));
                          } else {
                            context.read<AuthProvider>().refresh();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('🎉 Redeemed "${reward.title}"!')),
                            );
                          }
                        },
                        child: const Text('Redeem'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
      ],
    );
  }
}
