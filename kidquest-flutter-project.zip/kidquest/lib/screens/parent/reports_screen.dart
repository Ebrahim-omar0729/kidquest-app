import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/user_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../services/export_service.dart';
import '../../services/storage_service.dart';
import '../../utils/theme.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool _loading = false;

  Future<void> _generate({
    required ReportRange range,
    required bool asPdf,
  }) async {
    setState(() => _loading = true);
    try {
      final auth = context.read<AuthProvider>();
      final taskProvider = context.read<TaskProvider>();
      final parent = auth.currentParent!;
      final tasks = taskProvider.tasksForParent(parent.id);

      final kidsById = <String, KidUser>{
        for (final id in parent.kidIds)
          if (StorageService.kids.get(id) != null) id: StorageService.kids.get(id)!,
      };

      final file = asPdf
          ? await ExportService.exportPdf(
              allTasks: tasks,
              kidsById: kidsById,
              range: range,
              parentName: parent.name,
            )
          : await ExportService.exportCsv(
              allTasks: tasks,
              kidsById: kidsById,
              range: range,
            );

      await ExportService.shareFile(file);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Could not generate report: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Download Reports',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(
                'Export all approved tasks per kid as a PDF or CSV file you can save or share.',
                style: TextStyle(color: Colors.grey[600]),
              ),
              const SizedBox(height: 24),
              _ReportCard(
                title: 'Weekly Report',
                subtitle: 'Approved tasks from this week',
                icon: Icons.calendar_view_week_rounded,
                color: AppColors.primary,
                loading: _loading,
                onPdf: () => _generate(range: ReportRange.weekly, asPdf: true),
                onCsv: () => _generate(range: ReportRange.weekly, asPdf: false),
              ),
              const SizedBox(height: 16),
              _ReportCard(
                title: 'Monthly Report',
                subtitle: 'Approved tasks from this month',
                icon: Icons.calendar_month_rounded,
                color: AppColors.secondary,
                loading: _loading,
                onPdf: () => _generate(range: ReportRange.monthly, asPdf: true),
                onCsv: () => _generate(range: ReportRange.monthly, asPdf: false),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final bool loading;
  final VoidCallback onPdf;
  final VoidCallback onCsv;

  const _ReportCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.loading,
    required this.onPdf,
    required this.onCsv,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(icon, color: color),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Text(subtitle,
                          style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: loading ? null : onPdf,
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    label: const Text('PDF'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: loading ? null : onCsv,
                    icon: const Icon(Icons.table_chart_outlined),
                    label: const Text('CSV'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
