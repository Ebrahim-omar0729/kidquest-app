import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/task_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/task_card.dart';
import '../../widgets/points_badge.dart';
import '../auth/role_selection_screen.dart';
import 'task_form_screen.dart';
import 'approval_screen.dart';
import 'rewards_manage_screen.dart';
import 'kids_manage_screen.dart';
import 'reports_screen.dart';

class ParentDashboardScreen extends StatefulWidget {
  const ParentDashboardScreen({super.key});

  @override
  State<ParentDashboardScreen> createState() => _ParentDashboardScreenState();
}

class _ParentDashboardScreenState extends State<ParentDashboardScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final parent = auth.currentParent!;

    final pages = [
      _DashboardHome(parentId: parent.id),
      const KidsManageScreen(),
      const RewardsManageScreen(),
      const ReportsScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('KidQuest · Parent'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Log out',
            onPressed: () async {
              await auth.logout();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: pages[_tab],
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TaskFormScreen()),
              ),
              icon: const Icon(Icons.add),
              label: const Text('New Task'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.family_restroom), label: 'Kids'),
          NavigationDestination(icon: Icon(Icons.card_giftcard), label: 'Rewards'),
          NavigationDestination(icon: Icon(Icons.picture_as_pdf), label: 'Reports'),
        ],
      ),
    );
  }
}

class _DashboardHome extends StatelessWidget {
  final String parentId;
  const _DashboardHome({required this.parentId});

  @override
  Widget build(BuildContext context) {
    final taskProvider = context.watch<TaskProvider>();
    final tasks = taskProvider.tasksForParent(parentId);
    final pending = taskProvider.pendingApprovals(parentId);

    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final monthStart = DateTime(now.year, now.month, 1);

    final doneThisWeek =
        tasks.where((t) => t.status == TaskStatus.approved && t.approvedAt != null && t.approvedAt!.isAfter(weekStart)).length;
    final doneThisMonth =
        tasks.where((t) => t.status == TaskStatus.approved && t.approvedAt != null && t.approvedAt!.isAfter(monthStart)).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [
        if (pending.isNotEmpty)
          Card(
            color: AppColors.secondary.withOpacity(0.12),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: const Icon(Icons.notifications_active_rounded,
                  color: AppColors.secondary, size: 32),
              title: Text('${pending.length} task(s) waiting for your approval',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Tap to review and approve'),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ApprovalScreen()),
              ),
            ),
          ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: StatCard(
                label: 'Tasks done this week',
                value: '$doneThisWeek',
                icon: Icons.check_circle_rounded,
                color: AppColors.success,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatCard(
                label: 'Tasks done this month',
                value: '$doneThisMonth',
                icon: Icons.calendar_month_rounded,
                color: AppColors.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('All Tasks',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (tasks.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No tasks yet — tap "New Task" to create one!',
                  style: TextStyle(color: Colors.grey[500])),
            ),
          )
        else
          ...tasks.map(
            (t) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TaskCard(
                task: t,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TaskFormScreen(existingTask: t)),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
