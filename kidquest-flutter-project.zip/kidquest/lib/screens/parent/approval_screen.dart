import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../services/storage_service.dart';
import '../../utils/theme.dart';
import '../../widgets/task_card.dart';
import '../../widgets/pin_dialog.dart';

class ApprovalScreen extends StatelessWidget {
  const ApprovalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final taskProvider = context.watch<TaskProvider>();
    final pending = taskProvider.pendingApprovals(auth.currentParent!.id);

    return Scaffold(
      appBar: AppBar(title: const Text('Approvals')),
      body: pending.isEmpty
          ? Center(
              child: Text('Nothing waiting for approval 🎉',
                  style: TextStyle(color: Colors.grey[500], fontSize: 16)),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: pending.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final task = pending[i];
                final kid = StorageService.kids.get(task.assignedKidId);
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (kid != null)
                      Padding(
                        padding: const EdgeInsets.only(left: 4, bottom: 4),
                        child: Text('${kid.avatar} ${kid.username}',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    TaskCard(task: task),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.danger,
                              side: const BorderSide(color: AppColors.danger),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16)),
                            ),
                            onPressed: () async {
                              final ok = await showParentPinDialog(context,
                                  reason: 'Enter your PIN to reject this task.');
                              if (ok) {
                                await context.read<TaskProvider>().rejectTask(task);
                              }
                            },
                            icon: const Icon(Icons.close_rounded),
                            label: const Text('Reject'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.success),
                            onPressed: () async {
                              final ok = await showParentPinDialog(context,
                                  reason:
                                      'Enter your PIN to approve and award ${task.points} points.');
                              if (ok) {
                                await context.read<TaskProvider>().approveTask(task);
                                context.read<AuthProvider>().refresh();
                              }
                            },
                            icon: const Icon(Icons.check_rounded),
                            label: const Text('Approve'),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            ),
    );
  }
}
