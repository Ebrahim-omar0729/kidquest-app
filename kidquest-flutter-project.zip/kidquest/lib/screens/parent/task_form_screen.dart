import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/task_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../models/user_model.dart';
import '../../services/storage_service.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/pin_dialog.dart';

class TaskFormScreen extends StatefulWidget {
  final TaskModel? existingTask;
  const TaskFormScreen({super.key, this.existingTask});

  @override
  State<TaskFormScreen> createState() => _TaskFormScreenState();
}

class _TaskFormScreenState extends State<TaskFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _title;
  late TextEditingController _description;
  late TextEditingController _points;
  DateTime _dueDate = DateTime.now().add(const Duration(days: 1));
  String? _assignedKidId;
  String _icon = TaskIcons.keys.first;
  bool get _isEditing => widget.existingTask != null;

  @override
  void initState() {
    super.initState();
    final t = widget.existingTask;
    _title = TextEditingController(text: t?.title ?? '');
    _description = TextEditingController(text: t?.description ?? '');
    _points = TextEditingController(text: t != null ? t.points.toString() : '10');
    if (t != null) {
      _dueDate = t.dueDate;
      _assignedKidId = t.assignedKidId;
      _icon = t.icon;
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _dueDate = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_assignedKidId == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Please assign a kid to this task')));
      return;
    }

    final auth = context.read<AuthProvider>();
    final taskProvider = context.read<TaskProvider>();
    final parentId = auth.currentParent!.id;
    final points = int.tryParse(_points.text.trim()) ?? 0;

    if (_isEditing) {
      final confirmed = await showParentPinDialog(context,
          reason: 'Enter your PIN to save changes to this task.');
      if (!confirmed) return;
      await taskProvider.updateTask(
        widget.existingTask!,
        title: _title.text.trim(),
        description: _description.text.trim(),
        points: points,
        dueDate: _dueDate,
        assignedKidId: _assignedKidId,
        icon: _icon,
      );
    } else {
      await taskProvider.createTask(
        title: _title.text.trim(),
        description: _description.text.trim(),
        points: points,
        dueDate: _dueDate,
        assignedKidId: _assignedKidId!,
        parentId: parentId,
        icon: _icon,
      );
    }

    if (!mounted) return;
    Navigator.pop(context);
  }

  Future<void> _delete() async {
    final confirmed = await showParentPinDialog(context,
        reason: 'Enter your PIN to delete this task.');
    if (!confirmed) return;
    await context.read<TaskProvider>().deleteTask(widget.existingTask!);
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final parent = auth.currentParent!;
    final kids = parent.kidIds
        .map((id) => StorageService.kids.get(id))
        .whereType<KidUser>()
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Task' : 'New Task'),
        actions: [
          if (_isEditing)
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
              onPressed: _delete,
            ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _title,
                  decoration: const InputDecoration(labelText: 'Task title'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Enter a title' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _description,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Description'),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _points,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Points / reward value'),
                  validator: (v) {
                    final n = int.tryParse(v ?? '');
                    if (n == null || n <= 0) return 'Enter a valid point value';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                InkWell(
                  onTap: _pickDate,
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Due date'),
                    child: Text(
                      '${_dueDate.year}-${_dueDate.month.toString().padLeft(2, '0')}-${_dueDate.day.toString().padLeft(2, '0')}',
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<String>(
                  value: _assignedKidId,
                  decoration: const InputDecoration(labelText: 'Assign to kid'),
                  items: kids
                      .map(
                        (k) => DropdownMenuItem(
                          value: k.id,
                          child: Text('${k.avatar}  ${k.username}'),
                        ),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => _assignedKidId = v),
                ),
                const SizedBox(height: 14),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Icon', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: TaskIcons.keys.map((key) {
                    final selected = key == _icon;
                    return GestureDetector(
                      onTap: () => setState(() => _icon = key),
                      child: Container(
                        width: 52,
                        height: 52,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: selected
                              ? AppColors.primary.withOpacity(0.2)
                              : Colors.grey.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: selected ? AppColors.primary : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: Icon(TaskIcons.materialIcons[key],
                            color: selected ? AppColors.primary : Colors.grey[700]),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 26),
                ElevatedButton(
                  onPressed: _save,
                  child: Text(_isEditing ? 'Save Changes' : 'Create Task'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
