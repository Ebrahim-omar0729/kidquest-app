import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/reward_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/reward_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/pin_dialog.dart';

class RewardsManageScreen extends StatelessWidget {
  const RewardsManageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final rewardProvider = context.watch<RewardProvider>();
    final rewards = rewardProvider.rewardsForParent(auth.currentParent!.id);

    return Scaffold(
      body: rewards.isEmpty
          ? Center(
              child: Text('No rewards yet. Tap + to add one!',
                  style: TextStyle(color: Colors.grey[500])),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              itemCount: rewards.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final reward = rewards[i];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: CircleAvatar(
                      radius: 26,
                      backgroundColor: AppColors.secondary.withOpacity(0.15),
                      child: Text(reward.icon, style: const TextStyle(fontSize: 22)),
                    ),
                    title: Text(reward.title,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${reward.pointsRequired} points required'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => _showRewardDialog(context, reward: reward),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded,
                              color: AppColors.danger),
                          onPressed: () async {
                            final ok = await showParentPinDialog(context,
                                reason: 'Enter your PIN to delete this reward.');
                            if (ok) {
                              await context.read<RewardProvider>().deleteReward(reward);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showRewardDialog(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showRewardDialog(BuildContext context, {RewardModel? reward}) {
    final titleCtrl = TextEditingController(text: reward?.title ?? '');
    final pointsCtrl =
        TextEditingController(text: reward != null ? reward.pointsRequired.toString() : '50');
    String icon = reward?.icon ?? '🎁';
    const emojiOptions = ['🎁', '🍦', '🍕', '📱', '🎬', '🧸', '🎮', '🚲', '⭐'];

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(reward == null ? 'New Reward' : 'Edit Reward'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Wrap(
                  spacing: 8,
                  children: emojiOptions.map((e) {
                    final selected = e == icon;
                    return GestureDetector(
                      onTap: () => setState(() => icon = e),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: selected
                              ? AppColors.primary.withOpacity(0.2)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(e, style: const TextStyle(fontSize: 22)),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(labelText: 'Reward title'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: pointsCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Points required'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final title = titleCtrl.text.trim();
                final points = int.tryParse(pointsCtrl.text.trim()) ?? 0;
                if (title.isEmpty || points <= 0) return;

                final provider = ctx.read<RewardProvider>();
                if (reward == null) {
                  final parentId = ctx.read<AuthProvider>().currentParent!.id;
                  await provider.createReward(
                    title: title,
                    icon: icon,
                    pointsRequired: points,
                    parentId: parentId,
                  );
                } else {
                  await provider.updateReward(reward,
                      title: title, icon: icon, pointsRequired: points);
                }
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
