import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/user_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/task_provider.dart';
import '../../services/storage_service.dart';
import '../../utils/theme.dart';
import '../../widgets/pin_dialog.dart';
import '../../widgets/points_badge.dart';

class KidsManageScreen extends StatelessWidget {
  const KidsManageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final taskProvider = context.watch<TaskProvider>();
    final parent = auth.currentParent!;
    final kids = parent.kidIds
        .map((id) => StorageService.kids.get(id))
        .whereType<KidUser>()
        .toList();

    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: AppColors.primary.withOpacity(0.08),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.qr_code_2_rounded, color: AppColors.primary, size: 32),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Family Code',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(
                          'Share this with your kids so they can join: ${parent.familyCode}',
                          style: TextStyle(color: Colors.grey[700], fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('My Kids', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          if (kids.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 30),
              child: Center(
                child: Text(
                  'No kids linked yet. Share your family code so a kid can sign up.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey[500]),
                ),
              ),
            )
          else
            ...kids.map((kid) {
              final now = DateTime.now();
              final weekStart = now.subtract(Duration(days: now.weekday - 1));
              final tasksThisWeek = taskProvider.completedCountInRange(kid.id, weekStart);

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 28,
                          backgroundColor: AppColors.primary.withOpacity(0.12),
                          child: Text(kid.avatar, style: const TextStyle(fontSize: 26)),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(kid.username,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold, fontSize: 16)),
                              const SizedBox(height: 4),
                              Text('$tasksThisWeek tasks done this week',
                                  style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                            ],
                          ),
                        ),
                        PointsBadge(points: kid.totalPoints),
                        IconButton(
                          icon: const Icon(Icons.person_remove_outlined,
                              color: AppColors.danger),
                          onPressed: () async {
                            final ok = await showParentPinDialog(context,
                                reason: 'Enter your PIN to remove ${kid.username}.');
                            if (!ok) return;
                            parent.kidIds.remove(kid.id);
                            await parent.save();
                            await kid.delete();
                            context.read<AuthProvider>().refresh();
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}
