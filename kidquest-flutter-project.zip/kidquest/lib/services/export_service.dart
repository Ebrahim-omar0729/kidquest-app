import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../models/task_model.dart';
import '../models/user_model.dart';

enum ReportRange { weekly, monthly }

class ExportService {
  static DateTime _rangeStart(ReportRange range) {
    final now = DateTime.now();
    if (range == ReportRange.weekly) {
      final monday = now.subtract(Duration(days: now.weekday - 1));
      return DateTime(monday.year, monday.month, monday.day);
    }
    return DateTime(now.year, now.month, 1);
  }

  static List<TaskModel> _filter(List<TaskModel> tasks, ReportRange range) {
    final start = _rangeStart(range);
    return tasks
        .where((t) =>
            t.status == TaskStatus.approved &&
            t.approvedAt != null &&
            t.approvedAt!.isAfter(start))
        .toList();
  }

  static Future<File> exportCsv({
    required List<TaskModel> allTasks,
    required Map<String, KidUser> kidsById,
    required ReportRange range,
  }) async {
    final tasks = _filter(allTasks, range);
    final rows = <List<String>>[
      ['Kid', 'Task', 'Points', 'Completed On', 'Approved On'],
      ...tasks.map((t) => [
            kidsById[t.assignedKidId]?.username ?? 'Unknown',
            t.title,
            t.points.toString(),
            t.completedAt != null
                ? DateFormat('yyyy-MM-dd').format(t.completedAt!)
                : '-',
            t.approvedAt != null
                ? DateFormat('yyyy-MM-dd').format(t.approvedAt!)
                : '-',
          ]),
    ];
    final csvString = const ListToCsvConverter().convert(rows);

    final dir = await getApplicationDocumentsDirectory();
    final label = range == ReportRange.weekly ? 'weekly' : 'monthly';
    final file = File(
      '${dir.path}/kidquest_${label}_report_${DateTime.now().millisecondsSinceEpoch}.csv',
    );
    await file.writeAsString(csvString);
    return file;
  }

  static Future<File> exportPdf({
    required List<TaskModel> allTasks,
    required Map<String, KidUser> kidsById,
    required ReportRange range,
    required String parentName,
  }) async {
    final tasks = _filter(allTasks, range);
    final doc = pw.Document();
    final label = range == ReportRange.weekly ? 'Weekly' : 'Monthly';

    // Group by kid for a per-kid summary.
    final byKid = <String, List<TaskModel>>{};
    for (final t in tasks) {
      byKid.putIfAbsent(t.assignedKidId, () => []).add(t);
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Header(
            level: 0,
            child: pw.Text(
              'KidQuest $label Report',
              style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.Text('Prepared for: $parentName'),
          pw.Text('Generated: ${DateFormat('yyyy-MM-dd – HH:mm').format(DateTime.now())}'),
          pw.SizedBox(height: 16),
          ...byKid.entries.map((entry) {
            final kid = kidsById[entry.key];
            final totalPts =
                entry.value.fold<int>(0, (sum, t) => sum + t.points);
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(height: 12),
                pw.Text(
                  '${kid?.username ?? 'Unknown kid'} — $totalPts pts earned',
                  style: pw.TextStyle(
                      fontSize: 16, fontWeight: pw.FontWeight.bold),
                ),
                pw.Table.fromTextArray(
                  headers: ['Task', 'Points', 'Approved On'],
                  data: entry.value
                      .map((t) => [
                            t.title,
                            t.points.toString(),
                            t.approvedAt != null
                                ? DateFormat('MMM d, yyyy')
                                    .format(t.approvedAt!)
                                : '-',
                          ])
                      .toList(),
                ),
              ],
            );
          }),
          if (tasks.isEmpty)
            pw.Text('No approved tasks in this period yet.'),
        ],
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final labelLower = range == ReportRange.weekly ? 'weekly' : 'monthly';
    final file = File(
      '${dir.path}/kidquest_${labelLower}_report_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    await file.writeAsBytes(await doc.save());
    return file;
  }

  static Future<void> shareFile(File file) async {
    await Share.shareXFiles([XFile(file.path)]);
  }
}
