import 'package:hive_flutter/hive_flutter.dart';
import '../models/user_model.dart';
import '../models/task_model.dart';
import '../models/reward_model.dart';

/// Central place for Hive box names + init logic.
class StorageService {
  static const String parentsBox = 'parents_box';
  static const String kidsBox = 'kids_box';
  static const String tasksBox = 'tasks_box';
  static const String rewardsBox = 'rewards_box';
  static const String redemptionsBox = 'redemptions_box';
  static const String sessionBox = 'session_box';

  static Future<void> init() async {
    await Hive.initFlutter();

    Hive.registerAdapter(ParentUserAdapter());
    Hive.registerAdapter(KidUserAdapter());
    Hive.registerAdapter(TaskModelAdapter());
    Hive.registerAdapter(RewardModelAdapter());
    Hive.registerAdapter(RedemptionModelAdapter());

    await Hive.openBox<ParentUser>(parentsBox);
    await Hive.openBox<KidUser>(kidsBox);
    await Hive.openBox<TaskModel>(tasksBox);
    await Hive.openBox<RewardModel>(rewardsBox);
    await Hive.openBox<RedemptionModel>(redemptionsBox);
    await Hive.openBox(sessionBox); // simple key/value session data
  }

  static Box<ParentUser> get parents => Hive.box<ParentUser>(parentsBox);
  static Box<KidUser> get kids => Hive.box<KidUser>(kidsBox);
  static Box<TaskModel> get tasks => Hive.box<TaskModel>(tasksBox);
  static Box<RewardModel> get rewards => Hive.box<RewardModel>(rewardsBox);
  static Box<RedemptionModel> get redemptions =>
      Hive.box<RedemptionModel>(redemptionsBox);
  static Box get session => Hive.box(sessionBox);
}
