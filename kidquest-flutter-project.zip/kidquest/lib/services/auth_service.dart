import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart' show sha256;
import 'package:uuid/uuid.dart';
import '../models/user_model.dart';
import 'storage_service.dart';

/// NOTE: We hash passwords with sha256 for a lightweight demo-level of
/// security. This is NOT meant for a real production auth system --
/// swap in a real backend / secure auth provider for that.
class AuthService {
  static const _uuid = Uuid();

  static String hash(String input) {
    return sha256.convert(utf8.encode(input)).toString();
  }

  static String _generateFamilyCode() {
    final rand = Random();
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    return List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  /// Returns the created ParentUser, or throws a String error message.
  static Future<ParentUser> signUpParent({
    required String name,
    required String email,
    required String password,
    required String pin,
  }) async {
    final box = StorageService.parents;
    final exists = box.values.any(
      (p) => p.email.toLowerCase() == email.toLowerCase(),
    );
    if (exists) {
      throw 'An account with this email already exists.';
    }
    if (pin.length != 4 || int.tryParse(pin) == null) {
      throw 'PIN must be exactly 4 digits.';
    }

    final parent = ParentUser(
      id: _uuid.v4(),
      name: name,
      email: email,
      passwordHash: hash(password),
      pin: pin,
      familyCode: _generateFamilyCode(),
    );
    await box.put(parent.id, parent);
    return parent;
  }

  static Future<ParentUser> loginParent({
    required String email,
    required String password,
  }) async {
    final box = StorageService.parents;
    final match = box.values.where(
      (p) =>
          p.email.toLowerCase() == email.toLowerCase() &&
          p.passwordHash == hash(password),
    );
    if (match.isEmpty) {
      throw 'Invalid email or password.';
    }
    return match.first;
  }

  static ParentUser? findParentByFamilyCode(String code) {
    final box = StorageService.parents;
    try {
      return box.values.firstWhere(
        (p) => p.familyCode.toUpperCase() == code.toUpperCase(),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<KidUser> signUpKid({
    required String username,
    required String password,
    required String familyCode,
    required String avatar,
  }) async {
    final parent = findParentByFamilyCode(familyCode);
    if (parent == null) {
      throw 'Family code not found. Ask your parent for the correct code.';
    }
    final kidBox = StorageService.kids;
    final exists = kidBox.values.any(
      (k) => k.username.toLowerCase() == username.toLowerCase(),
    );
    if (exists) {
      throw 'That username is already taken.';
    }

    final kid = KidUser(
      id: _uuid.v4(),
      username: username,
      passwordHash: hash(password),
      parentId: parent.id,
      avatar: avatar,
    );
    await kidBox.put(kid.id, kid);

    parent.kidIds.add(kid.id);
    await parent.save();

    return kid;
  }

  static Future<KidUser> loginKid({
    required String username,
    required String password,
  }) async {
    final box = StorageService.kids;
    final match = box.values.where(
      (k) =>
          k.username.toLowerCase() == username.toLowerCase() &&
          k.passwordHash == hash(password),
    );
    if (match.isEmpty) {
      throw 'Invalid username or password.';
    }
    return match.first;
  }

  static bool verifyPin(ParentUser parent, String pin) => parent.pin == pin;

  // ---- Session persistence (so the app remembers who's logged in) ----
  static Future<void> saveSession({
    required String role, // 'parent' or 'kid'
    required String userId,
  }) async {
    await StorageService.session.put('role', role);
    await StorageService.session.put('userId', userId);
  }

  static Future<void> clearSession() async {
    await StorageService.session.clear();
  }

  static Map<String, String>? getSession() {
    final role = StorageService.session.get('role');
    final userId = StorageService.session.get('userId');
    if (role == null || userId == null) return null;
    return {'role': role as String, 'userId': userId as String};
  }
}
