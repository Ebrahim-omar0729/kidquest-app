import 'package:flutter/material.dart';

/// Task icon keys map to both an asset illustration (assets/images/*.svg)
/// and a Material fallback icon (used in small chips/badges).
class TaskIcons {
  static const Map<String, IconData> materialIcons = {
    'dishes': Icons.local_dining,
    'homework': Icons.menu_book,
    'bed': Icons.bed,
    'toys': Icons.toys,
    'trash': Icons.delete_outline,
    'pet': Icons.pets,
    'teeth': Icons.emoji_emotions,
    'laundry': Icons.local_laundry_service,
    'reading': Icons.auto_stories,
    'cleaning': Icons.cleaning_services,
  };

  static const Map<String, String> assetPaths = {
    'dishes': 'assets/images/task_dishes.svg',
    'homework': 'assets/images/task_homework.svg',
    'bed': 'assets/images/task_bed.svg',
    'toys': 'assets/images/task_toys.svg',
    'trash': 'assets/images/task_trash.svg',
    'pet': 'assets/images/task_pet.svg',
    'teeth': 'assets/images/task_teeth.svg',
    'laundry': 'assets/images/task_laundry.svg',
    'reading': 'assets/images/task_reading.svg',
    'cleaning': 'assets/images/task_cleaning.svg',
  };

  static List<String> get keys => assetPaths.keys.toList();
}

class KidAvatars {
  static const List<String> emojiAvatars = [
    '🦄', '🐯', '🐼', '🦊', '🐸', '🐵', '🦁', '🐶', '🐱', '🐰',
  ];
}
