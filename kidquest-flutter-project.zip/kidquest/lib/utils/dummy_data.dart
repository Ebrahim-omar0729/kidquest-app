import 'package:uuid/uuid.dart';
import '../models/task_model.dart';
import '../models/user_model.dart';
import '../models/reward_model.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';

/// Seeds demo data on first launch so testers can log straight in.
///
/// Demo parent login:  parent@kidquest.com / password123   (PIN: 1234)
/// Demo kid logins:    ava / kidpass   and   leo / kidpass
class DummyData {
  static const _uuid = Uuid();

  static Future<void> seedIfEmpty() async {
    if (StorageService.parents.isNotEmpty) return; // already seeded

    final parent = ParentUser(
      id: _uuid.v4(),
      name: 'Demo Parent',
      email: 'parent@kidquest.com',
      passwordHash: AuthService.hash('password123'),
      pin: '1234',
      familyCode: 'DEMO01',
    );
    await StorageService.parents.put(parent.id, parent);

    final ava = KidUser(
      id: _uuid.v4(),
      username: 'ava',
      passwordHash: AuthService.hash('kidpass'),
      parentId: parent.id,
      avatar: '🦄',
      totalPoints: 40,
    );
    final leo = KidUser(
      id: _uuid.v4(),
      username: 'leo',
      passwordHash: AuthService.hash('kidpass'),
      parentId: parent.id,
      avatar: '🐯',
      totalPoints: 15,
    );
    await StorageService.kids.put(ava.id, ava);
    await StorageService.kids.put(leo.id, leo);

    parent.kidIds
      ..add(ava.id)
      ..add(leo.id);
    await parent.save();

    final now = DateTime.now();
    final tasks = [
      TaskModel(
        id: _uuid.v4(),
        title: 'Wash the dishes',
        description: 'Clean all the plates and cups after dinner.',
        points: 10,
        dueDate: now.add(const Duration(days: 1)),
        assignedKidId: ava.id,
        parentId: parent.id,
        icon: 'dishes',
      ),
      TaskModel(
        id: _uuid.v4(),
        title: 'Finish homework',
        description: 'Complete math worksheet pages 4-5.',
        points: 20,
        dueDate: now.add(const Duration(days: 1)),
        assignedKidId: ava.id,
        parentId: parent.id,
        icon: 'homework',
        status: TaskStatus.waitingApproval,
        completedAt: now.subtract(const Duration(hours: 2)),
      ),
      TaskModel(
        id: _uuid.v4(),
        title: 'Make the bed',
        description: 'Tidy up sheets and pillows every morning.',
        points: 5,
        dueDate: now,
        assignedKidId: leo.id,
        parentId: parent.id,
        icon: 'bed',
        status: TaskStatus.approved,
        completedAt: now.subtract(const Duration(days: 1)),
        approvedAt: now.subtract(const Duration(days: 1)),
      ),
      TaskModel(
        id: _uuid.v4(),
        title: 'Put away toys',
        description: 'All toys back in the box before bedtime.',
        points: 8,
        dueDate: now.add(const Duration(days: 2)),
        assignedKidId: leo.id,
        parentId: parent.id,
        icon: 'toys',
      ),
      TaskModel(
        id: _uuid.v4(),
        title: 'Take out the trash',
        description: 'Empty the kitchen bin and take it to the curb.',
        points: 12,
        dueDate: now.add(const Duration(days: 3)),
        assignedKidId: ava.id,
        parentId: parent.id,
        icon: 'trash',
      ),
    ];
    for (final t in tasks) {
      await StorageService.tasks.put(t.id, t);
    }

    final rewards = [
      RewardModel(
        id: _uuid.v4(),
        title: 'Ice cream treat',
        icon: '🍦',
        pointsRequired: 50,
        parentId: parent.id,
      ),
      RewardModel(
        id: _uuid.v4(),
        title: '30 min extra screen time',
        icon: '📱',
        pointsRequired: 30,
        parentId: parent.id,
      ),
      RewardModel(
        id: _uuid.v4(),
        title: 'Movie night pick',
        icon: '🎬',
        pointsRequired: 80,
        parentId: parent.id,
      ),
      RewardModel(
        id: _uuid.v4(),
        title: 'New toy',
        icon: '🧸',
        pointsRequired: 150,
        parentId: parent.id,
      ),
    ];
    for (final r in rewards) {
      await StorageService.rewards.put(r.id, r);
    }
  }
}
