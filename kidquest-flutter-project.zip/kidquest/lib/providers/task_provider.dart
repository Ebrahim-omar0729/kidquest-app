import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/task_model.dart';
import '../models/user_model.dart';
import '../services/storage_service.dart';

class TaskProvider extends ChangeNotifier {
  static const _uuid = Uuid();

  List<TaskModel> get allTasks => StorageService.tasks.values.toList();

  List<TaskModel> tasksForParent(String parentId) => allTasks
      .where((t) => t.parentId == parentId)
      .toList()
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  List<TaskModel> tasksForKid(String kidId) => allTasks
      .where((t) => t.assignedKidId == kidId)
      .toList()
    ..sort((a, b) => a.dueDate.compareTo(b.dueDate));

  List<TaskModel> pendingApprovals(String parentId) => tasksForParent(parentId)
      .where((t) => t.status == TaskStatus.waitingApproval)
      .toList();

  Future<TaskModel> createTask({
    required String title,
    required String description,
    required int points,
    required DateTime dueDate,
    required String assignedKidId,
    required String parentId,
    required String icon,
  }) async {
    final task = TaskModel(
      id: _uuid.v4(),
      title: title,
      description: description,
      points: points,
      dueDate: dueDate,
      assignedKidId: assignedKidId,
      parentId: parentId,
      icon: icon,
    );
    await StorageService.tasks.put(task.id, task);
    notifyListeners();
    return task;
  }

  Future<void> updateTask(
    TaskModel task, {
    String? title,
    String? description,
    int? points,
    DateTime? dueDate,
    String? assignedKidId,
    String? icon,
  }) async {
    if (title != null) task.title = title;
    if (description != null) task.description = description;
    if (points != null) task.points = points;
    if (dueDate != null) task.dueDate = dueDate;
    if (assignedKidId != null) task.assignedKidId = assignedKidId;
    if (icon != null) task.icon = icon;
    await task.save();
    notifyListeners();
  }

  Future<void> deleteTask(TaskModel task) async {
    await task.delete();
    notifyListeners();
  }

  /// Kid marks a task done -> goes to "waiting approval".
  Future<void> markDoneByKid(TaskModel task) async {
    task.status = TaskStatus.waitingApproval;
    task.completedAt = DateTime.now();
    await task.save();
    notifyListeners();
  }

  /// Parent approves -> awards points to the kid.
  Future<void> approveTask(TaskModel task) async {
    task.status = TaskStatus.approved;
    task.approvedAt = DateTime.now();
    await task.save();

    final kid = StorageService.kids.get(task.assignedKidId);
    if (kid != null) {
      kid.totalPoints += task.points;
      await kid.save();
    }
    notifyListeners();
  }

  /// Parent rejects -> task goes back to pending, no points awarded.
  Future<void> rejectTask(TaskModel task) async {
    task.status = TaskStatus.pending;
    task.completedAt = null;
    await task.save();
    notifyListeners();
  }

  // ---- Stats helpers ----
  int completedCountInRange(String kidId, DateTime start) {
    return allTasks
        .where((t) =>
            t.assignedKidId == kidId &&
            t.status == TaskStatus.approved &&
            t.approvedAt != null &&
            t.approvedAt!.isAfter(start))
        .length;
  }

  int pointsEarnedInRange(String kidId, DateTime start) {
    return allTasks
        .where((t) =>
            t.assignedKidId == kidId &&
            t.status == TaskStatus.approved &&
            t.approvedAt != null &&
            t.approvedAt!.isAfter(start))
        .fold<int>(0, (sum, t) => sum + t.points);
  }
}
