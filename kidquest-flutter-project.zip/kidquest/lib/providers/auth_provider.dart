import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';

enum AppRole { none, parent, kid }

class AuthProvider extends ChangeNotifier {
  AppRole role = AppRole.none;
  ParentUser? currentParent;
  KidUser? currentKid;

  AuthProvider() {
    _restoreSession();
  }

  void _restoreSession() {
    final session = AuthService.getSession();
    if (session == null) return;
    if (session['role'] == 'parent') {
      final parent = StorageService.parents.get(session['userId']);
      if (parent != null) {
        currentParent = parent;
        role = AppRole.parent;
      }
    } else if (session['role'] == 'kid') {
      final kid = StorageService.kids.get(session['userId']);
      if (kid != null) {
        currentKid = kid;
        role = AppRole.kid;
      }
    }
  }

  Future<void> loginParent(String email, String password) async {
    final parent = await AuthService.loginParent(email: email, password: password);
    currentParent = parent;
    role = AppRole.parent;
    await AuthService.saveSession(role: 'parent', userId: parent.id);
    notifyListeners();
  }

  Future<void> signUpParent({
    required String name,
    required String email,
    required String password,
    required String pin,
  }) async {
    final parent = await AuthService.signUpParent(
      name: name,
      email: email,
      password: password,
      pin: pin,
    );
    currentParent = parent;
    role = AppRole.parent;
    await AuthService.saveSession(role: 'parent', userId: parent.id);
    notifyListeners();
  }

  Future<void> loginKid(String username, String password) async {
    final kid = await AuthService.loginKid(username: username, password: password);
    currentKid = kid;
    role = AppRole.kid;
    await AuthService.saveSession(role: 'kid', userId: kid.id);
    notifyListeners();
  }

  Future<void> signUpKid({
    required String username,
    required String password,
    required String familyCode,
    required String avatar,
  }) async {
    final kid = await AuthService.signUpKid(
      username: username,
      password: password,
      familyCode: familyCode,
      avatar: avatar,
    );
    currentKid = kid;
    role = AppRole.kid;
    await AuthService.saveSession(role: 'kid', userId: kid.id);
    notifyListeners();
  }

  bool verifyParentPin(String pin) {
    if (currentParent == null) return false;
    return AuthService.verifyPin(currentParent!, pin);
  }

  Future<void> logout() async {
    role = AppRole.none;
    currentParent = null;
    currentKid = null;
    await AuthService.clearSession();
    notifyListeners();
  }

  /// Refresh currentParent/currentKid from Hive (e.g. after points change).
  void refresh() {
    if (role == AppRole.parent && currentParent != null) {
      currentParent = StorageService.parents.get(currentParent!.id);
    } else if (role == AppRole.kid && currentKid != null) {
      currentKid = StorageService.kids.get(currentKid!.id);
    }
    notifyListeners();
  }
}
