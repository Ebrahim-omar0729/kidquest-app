import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/reward_model.dart';
import '../models/user_model.dart';
import '../services/storage_service.dart';

class RewardProvider extends ChangeNotifier {
  static const _uuid = Uuid();

  List<RewardModel> rewardsForParent(String parentId) => StorageService
      .rewards.values
      .where((r) => r.parentId == parentId)
      .toList()
    ..sort((a, b) => a.pointsRequired.compareTo(b.pointsRequired));

  List<RedemptionModel> redemptionsForKid(String kidId) => StorageService
      .redemptions.values
      .where((r) => r.kidId == kidId)
      .toList()
    ..sort((a, b) => b.redeemedAt.compareTo(a.redeemedAt));

  Future<RewardModel> createReward({
    required String title,
    required String icon,
    required int pointsRequired,
    required String parentId,
  }) async {
    final reward = RewardModel(
      id: _uuid.v4(),
      title: title,
      icon: icon,
      pointsRequired: pointsRequired,
      parentId: parentId,
    );
    await StorageService.rewards.put(reward.id, reward);
    notifyListeners();
    return reward;
  }

  Future<void> updateReward(
    RewardModel reward, {
    String? title,
    String? icon,
    int? pointsRequired,
  }) async {
    if (title != null) reward.title = title;
    if (icon != null) reward.icon = icon;
    if (pointsRequired != null) reward.pointsRequired = pointsRequired;
    await reward.save();
    notifyListeners();
  }

  Future<void> deleteReward(RewardModel reward) async {
    await reward.delete();
    notifyListeners();
  }

  /// Returns null on success, or an error message string on failure.
  Future<String?> redeem({
    required RewardModel reward,
    required KidUser kid,
  }) async {
    if (kid.totalPoints < reward.pointsRequired) {
      return 'Not enough points yet! Keep completing tasks.';
    }
    kid.totalPoints -= reward.pointsRequired;
    await kid.save();

    final redemption = RedemptionModel(
      id: _uuid.v4(),
      rewardId: reward.id,
      rewardTitle: reward.title,
      kidId: kid.id,
      pointsSpent: reward.pointsRequired,
    );
    await StorageService.redemptions.put(redemption.id, redemption);
    notifyListeners();
    return null;
  }
}
