import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../utils/theme.dart';

/// Shows a modal asking for the 4-digit parent PIN.
/// Returns true if the PIN was correct, false/null otherwise.
Future<bool> showParentPinDialog(BuildContext context, {String? reason}) async {
  final controller = TextEditingController();
  final auth = context.read<AuthProvider>();
  String? error;

  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      return StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('Enter Parent PIN'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (reason != null) ...[
                Text(reason, style: TextStyle(color: Colors.grey[600])),
                const SizedBox(height: 12),
              ],
              TextField(
                controller: controller,
                autofocus: true,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, letterSpacing: 8),
                decoration: InputDecoration(
                  counterText: '',
                  errorText: error,
                  hintText: '••••',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
              onPressed: () {
                if (auth.verifyParentPin(controller.text.trim())) {
                  Navigator.pop(ctx, true);
                } else {
                  setState(() => error = 'Incorrect PIN, try again.');
                }
              },
              child: const Text('Confirm'),
            ),
          ],
        ),
      );
    },
  );

  return result ?? false;
}
