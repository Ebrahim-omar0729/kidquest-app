import 'package:hive/hive.dart';

enum TaskStatus { pending, waitingApproval, approved, rejected }

/// typeId 2
class TaskModel extends HiveObject {
  String id;
  String title;
  String description;
  int points;
  DateTime dueDate;
  String assignedKidId;
  String parentId;
  String icon; // key referencing an asset / icon
  TaskStatus status;
  DateTime createdAt;
  DateTime? completedAt;
  DateTime? approvedAt;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.dueDate,
    required this.assignedKidId,
    required this.parentId,
    required this.icon,
    this.status = TaskStatus.pending,
    DateTime? createdAt,
    this.completedAt,
    this.approvedAt,
  }) : createdAt = createdAt ?? DateTime.now();
}

class TaskModelAdapter extends TypeAdapter<TaskModel> {
  @override
  final int typeId = 2;

  @override
  TaskModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return TaskModel(
      id: fields[0] as String,
      title: fields[1] as String,
      description: fields[2] as String,
      points: fields[3] as int,
      dueDate: fields[4] as DateTime,
      assignedKidId: fields[5] as String,
      parentId: fields[6] as String,
      icon: fields[7] as String,
      status: TaskStatus.values[fields[8] as int],
      createdAt: fields[9] as DateTime,
      completedAt: fields[10] as DateTime?,
      approvedAt: fields[11] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, TaskModel obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.points)
      ..writeByte(4)
      ..write(obj.dueDate)
      ..writeByte(5)
      ..write(obj.assignedKidId)
      ..writeByte(6)
      ..write(obj.parentId)
      ..writeByte(7)
      ..write(obj.icon)
      ..writeByte(8)
      ..write(obj.status.index)
      ..writeByte(9)
      ..write(obj.createdAt)
      ..writeByte(10)
      ..write(obj.completedAt)
      ..writeByte(11)
      ..write(obj.approvedAt);
  }
}
