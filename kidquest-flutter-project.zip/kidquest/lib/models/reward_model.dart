import 'package:hive/hive.dart';

/// typeId 3
class RewardModel extends HiveObject {
  String id;
  String title;
  String icon;
  int pointsRequired;
  String parentId;

  RewardModel({
    required this.id,
    required this.title,
    required this.icon,
    required this.pointsRequired,
    required this.parentId,
  });
}

class RewardModelAdapter extends TypeAdapter<RewardModel> {
  @override
  final int typeId = 3;

  @override
  RewardModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RewardModel(
      id: fields[0] as String,
      title: fields[1] as String,
      icon: fields[2] as String,
      pointsRequired: fields[3] as int,
      parentId: fields[4] as String,
    );
  }

  @override
  void write(BinaryWriter writer, RewardModel obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.icon)
      ..writeByte(3)
      ..write(obj.pointsRequired)
      ..writeByte(4)
      ..write(obj.parentId);
  }
}

/// typeId 4 - a log of redeemed rewards
class RedemptionModel extends HiveObject {
  String id;
  String rewardId;
  String rewardTitle;
  String kidId;
  int pointsSpent;
  DateTime redeemedAt;

  RedemptionModel({
    required this.id,
    required this.rewardId,
    required this.rewardTitle,
    required this.kidId,
    required this.pointsSpent,
    DateTime? redeemedAt,
  }) : redeemedAt = redeemedAt ?? DateTime.now();
}

class RedemptionModelAdapter extends TypeAdapter<RedemptionModel> {
  @override
  final int typeId = 4;

  @override
  RedemptionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RedemptionModel(
      id: fields[0] as String,
      rewardId: fields[1] as String,
      rewardTitle: fields[2] as String,
      kidId: fields[3] as String,
      pointsSpent: fields[4] as int,
      redeemedAt: fields[5] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, RedemptionModel obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.rewardId)
      ..writeByte(2)
      ..write(obj.rewardTitle)
      ..writeByte(3)
      ..write(obj.kidId)
      ..writeByte(4)
      ..write(obj.pointsSpent)
      ..writeByte(5)
      ..write(obj.redeemedAt);
  }
}
