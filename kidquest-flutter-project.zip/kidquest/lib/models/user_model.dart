import 'package:hive/hive.dart';

/// Parent account. typeId 0
class ParentUser extends HiveObject {
  String id;
  String name;
  String email;
  String passwordHash;
  String pin; // 4-digit parent PIN, required for sensitive actions
  String familyCode; // shareable code kids use to link their account
  List<String> kidIds;

  ParentUser({
    required this.id,
    required this.name,
    required this.email,
    required this.passwordHash,
    required this.pin,
    required this.familyCode,
    List<String>? kidIds,
  }) : kidIds = kidIds ?? [];
}

class ParentUserAdapter extends TypeAdapter<ParentUser> {
  @override
  final int typeId = 0;

  @override
  ParentUser read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ParentUser(
      id: fields[0] as String,
      name: fields[1] as String,
      email: fields[2] as String,
      passwordHash: fields[3] as String,
      pin: fields[4] as String,
      familyCode: fields[5] as String,
      kidIds: (fields[6] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, ParentUser obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.email)
      ..writeByte(3)
      ..write(obj.passwordHash)
      ..writeByte(4)
      ..write(obj.pin)
      ..writeByte(5)
      ..write(obj.familyCode)
      ..writeByte(6)
      ..write(obj.kidIds);
  }
}

/// Kid account. typeId 1
class KidUser extends HiveObject {
  String id;
  String username;
  String passwordHash;
  String parentId;
  String avatar; // asset path or emoji key
  int totalPoints;

  KidUser({
    required this.id,
    required this.username,
    required this.passwordHash,
    required this.parentId,
    required this.avatar,
    this.totalPoints = 0,
  });
}

class KidUserAdapter extends TypeAdapter<KidUser> {
  @override
  final int typeId = 1;

  @override
  KidUser read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return KidUser(
      id: fields[0] as String,
      username: fields[1] as String,
      passwordHash: fields[2] as String,
      parentId: fields[3] as String,
      avatar: fields[4] as String,
      totalPoints: fields[5] as int,
    );
  }

  @override
  void write(BinaryWriter writer, KidUser obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.username)
      ..writeByte(2)
      ..write(obj.passwordHash)
      ..writeByte(3)
      ..write(obj.parentId)
      ..writeByte(4)
      ..write(obj.avatar)
      ..writeByte(5)
      ..write(obj.totalPoints);
  }
}
