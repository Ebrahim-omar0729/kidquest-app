import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'providers/task_provider.dart';
import 'providers/reward_provider.dart';
import 'services/storage_service.dart';
import 'utils/dummy_data.dart';
import 'utils/theme.dart';
import 'screens/auth/role_selection_screen.dart';
import 'screens/parent/parent_dashboard_screen.dart';
import 'screens/kid/kid_dashboard_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  await DummyData.seedIfEmpty();
  runApp(const KidQuestApp());
}

class KidQuestApp extends StatelessWidget {
  const KidQuestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => TaskProvider()),
        ChangeNotifierProvider(create: (_) => RewardProvider()),
      ],
      child: MaterialApp(
        title: 'KidQuest - Reward Tasks',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const _StartupRouter(),
      ),
    );
  }
}

/// Routes to the correct home screen based on any restored session,
/// otherwise shows the role selection screen.
class _StartupRouter extends StatelessWidget {
  const _StartupRouter();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    switch (auth.role) {
      case AppRole.parent:
        return const ParentDashboardScreen();
      case AppRole.kid:
        return const KidDashboardScreen();
      case AppRole.none:
        return const RoleSelectionScreen();
    }
  }
}
