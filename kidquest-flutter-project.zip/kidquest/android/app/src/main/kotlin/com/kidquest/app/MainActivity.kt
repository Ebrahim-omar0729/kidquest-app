package com.kidquest.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
